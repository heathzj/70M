#include "define.h"
#include "i2c_c1.h"
#include "Global.h"


#include "oled_c1.h"
#include "oled_c2.h"

unsigned char LCDBufferPosition[2];
const char LOStatusString1[] = {"LOCKED  "}; 
const char LOStatusString2[] = {"UNLOCKED"}; 

/*Zj 950.000MHz to 2150.000MHz */
char LOFreqString1[] = {"7305.000MHz"}; /* must update to 3 digits decimal */
char LOFreqString2[] = {"7305.100MHz"}; /* must update to 3 digits decimal */
char RFFreqString1[] = {"8025.000MHz"}; /* must update to 3 digits decimal */
char RFFreqString2[] = {"8025.100MHz"}; /* must update to 3 digits decimal */
char AttenString1[] = {"10.0 dB"}; 
char AttenString2[] = {"12.5 dB"}; 
char IFString1[] = {"720 MHz"}; 
char IPString[] = {"192.168.001.001"}; 
char MNString[] = {"SCMDC62001SN10-RM"}; 
char SNString[] = {"12345678"}; 
char s18VDC[] = {"OFF"};
char s24VDC[] = {"OFF"};
char sUCPower = {"-30"};
char sDCPower = {"-30"};


unsigned char LastMenu = MENU0;
unsigned char CurrentMenu = MENU0;


unsigned char KeyPressedFlag = FALSE, PressedKey = NULL, RefreshFlag = FALSE;

unsigned char EditMode = FALSE, EditPosition = 0, FirstPressKey = TRUE;

tstI2CMessage  stI2CUCMsg;
tstI2CMessage  stI2CDCMsg;
tstI2CMessageVOL  stI2CVOLMsg;

#pragma udata gpr8
char LCDPrintBuffer[2][40];

#pragma udata grp10
char LCDBlinkBuffer[2][40];


typedef struct menustructure
{
	unsigned char editable;
} menustructure_t;
#define MaxMenuNum 		20
menustructure_t ConvertMenu[MaxMenuNum];



void DisplayCompanyMenu(void)
{

	strcpypgm2ram (LCDPrintBuffer[0], "                  SINGCOM               ");
	strcpypgm2ram (LCDPrintBuffer[1], "               DOWN CONVERTER           ");
}



void InitalizeMenu(void)
{
	unsigned char i;

	for (i = 0; i < 40; i++)
	{
		LCDPrintBuffer[0][i] = ' ';
		LCDPrintBuffer[1][i] = ' ';
		LCDBlinkBuffer[0][i] = ' ';
		LCDBlinkBuffer[1][i] = ' ';
	}	
	CurrentMenu = MENU0;
	IPString[0] = ((AppConfig.MyIPAddr.v[0] / 100) % 10) + '0';
	IPString[1] = ((AppConfig.MyIPAddr.v[0] / 10) % 10) + '0';
	IPString[2] = ((AppConfig.MyIPAddr.v[0] / 1) % 10) + '0';
	IPString[4] = ((AppConfig.MyIPAddr.v[1] / 100) % 10) + '0';
	IPString[5] = ((AppConfig.MyIPAddr.v[1] / 10) % 10) + '0';
	IPString[6] = ((AppConfig.MyIPAddr.v[1] / 1) % 10) + '0';
	IPString[8] = ((AppConfig.MyIPAddr.v[2] / 100) % 10) + '0';
	IPString[9] = ((AppConfig.MyIPAddr.v[2] / 10) % 10) + '0';
	IPString[10] = ((AppConfig.MyIPAddr.v[2] / 1) % 10) + '0';
	IPString[12] = ((AppConfig.MyIPAddr.v[3] / 100) % 10) + '0';
	IPString[13] = ((AppConfig.MyIPAddr.v[3] / 10) % 10) + '0';
	IPString[14] = ((AppConfig.MyIPAddr.v[3] / 1) % 10) + '0';

	// Level 0 Menu 0/1/2: DC1/DC2/INFO
	// DC1 Menu 3/4/5/6/7: LO Freq(Editable)/RF Freq/LO Status/Atten(Editable)/IF
	// DC2 Menu 8/9/10/11/12: LO Freq(Editable)/RF Freq/LO Status/Atten(Editable)/IF
	// INFO Menu 13/14/15: IP(Editable)/MN/SN
	
	ConvertMenu[0].editable = FALSE;
	ConvertMenu[1].editable = FALSE;
	ConvertMenu[2].editable = FALSE;
	ConvertMenu[3].editable = TRUE;
	ConvertMenu[4].editable = FALSE;
	ConvertMenu[5].editable = FALSE;
	ConvertMenu[6].editable = TRUE;
	ConvertMenu[7].editable = FALSE;
	ConvertMenu[8].editable = TRUE;
	ConvertMenu[9].editable = FALSE;
	ConvertMenu[10].editable = FALSE;
	ConvertMenu[11].editable = TRUE;
	ConvertMenu[12].editable = FALSE;
	ConvertMenu[13].editable = TRUE;
	ConvertMenu[14].editable = FALSE;
	ConvertMenu[15].editable = FALSE;
}




void DisplayMenu(void)
{
	unsigned char i;
	
	// Level 0 Menu 0/1/2: DC1/DC2/INFO
	// DC1 Menu 3/4/5/6/7: LO Freq(Editable)/RF Freq/LO Status/Atten(Editable)/IF
	// DC2 Menu 8/9/10/11/12: LO Freq(Editable)/RF Freq/LO Status/Atten(Editable)/IF
	// INFO Menu 13/14/15: IP(Editable)/MN/SN
    
    
    /**************New Menu ******************/
    // Level 0 Menu 0/1/2/3: UC1/DC2/DCVOL/INFO
	// UC1     Menu 4/5/6/7/8/9: Output Freq(Editable)/Output Power(E)/LO Status/Atten(E)/ALC(E)/Mute(E)
	// DC2     Menu 10/11/12/13/14/15: Input Freq(Editable)/Output Power(E)/LO Status/Atten(E)/ALC(E)/Mute(E)
    // DCVOL   Menu 16/17: 18V DC(E) / 24V DC(E)
	// INFO Menu 18/19/20: IP(Editable)/MN/SN
    
	switch (CurrentMenu)
	{


/***************************Main Page*****************************************/	
		case MENU0:
		{
            strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1] [CVT.2] [DC VOL] [DEVICE INFO]  ");
//			strcpypgm2ram(LCDPrintBuffer[1], "RF 7305.000MHz PWER -30 dB LO UNLOCKED ");
			strcpypgm2ram(LCDPrintBuffer[1], "RF ");
			strcat(LCDPrintBuffer[1], RFFreqString1);
			strcatpgm2ram(LCDPrintBuffer[1], " PWER ");
			strcat(LCDPrintBuffer[1], sUCPower);
			strcatpgm2ram(LCDPrintBuffer[1], " LO ");
			if (stConverter.stUp.u8Lock == OK)
			{
				strcat(LCDPrintBuffer[1], LOStatusString1);
			}
			else
			{
				strcat(LCDPrintBuffer[1], LOStatusString2);
			}
			strcatpgm2ram(LCDPrintBuffer[1], " ");

              strcpypgm2ram(LCDPrintBuffer[0], "        [CVT.2] [DC VOL] [DEVICE INFO]  ");
		    //strcpypgm2ram(LCDBlinkBuffer[0], "            [CVT.2]     [DEVICCE INFO]  ");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU1:
		{
            strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1] [CVT.2] [DC VOL] [DEVICE INFO]  ");
//			strcpypgm2ram(LCDPrintBuffer[1], "RF 7305.000MHz PWER -30 dB LO UNLOCKED ");
			strcpypgm2ram(LCDPrintBuffer[1], "RF ");
			strcat(LCDPrintBuffer[1], RFFreqString2);
			strcatpgm2ram(LCDPrintBuffer[1], " PWER ");
			strcat(LCDPrintBuffer[1], sDCPower);
			strcatpgm2ram(LCDPrintBuffer[1], " LO ");
			if (stConverter.stDown.u8Lock == OK)
			{
				strcat(LCDPrintBuffer[1], LOStatusString1);
			}
			else
			{
				strcat(LCDPrintBuffer[1], LOStatusString2);
			}
			strcatpgm2ram(LCDPrintBuffer[1], " ");

			
			strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1]         [DC VOL] [DEVICE INFO]  ");
			//strcpypgm2ram(LCDBlinkBuffer[0], "[CVT.1]                 [DEVICCE INFO]  ");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU2:
		{
            strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1] [CVT.2] [DC VOL] [DEVICE INFO]  ");
		  //strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1]     [CVT.2]     [DEVICCE INFO]  ");
//			strcpypgm2ram(LCDPrintBuffer[1], "18VDC ON 24VDC OFF                      ");
			strcpypgm2ram(LCDPrintBuffer[1], "18VDC ");
			strcat(LCDPrintBuffer[1], s18VDC);
			strcatpgm2ram(LCDPrintBuffer[1], " 24VDC ");
			strcat(LCDPrintBuffer[1], s24VDC);

			strcatpgm2ram(LCDPrintBuffer[1], "                     ");

			strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1] [CVT.2]          [DEVICE INFO]  ");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;

		case MENU3:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1] [CVT.2] [DC VOL] [DEVICE INFO]  ");
		  //strcpypgm2ram(LCDPrintBuffer[0], "[CVT.1]	  [CVT.2]	  [DEVICCE INFO]  ");
//			strcpypgm2ram(LCDPrintBuffer[1], "IP 192.168.1.1 MN SCMDC62001SN10-RM SN 1");
			strcpypgm2ram(LCDPrintBuffer[1], "IP ");
			IPString[0] = ((AppConfig.MyIPAddr.v[0] / 100) % 10) + '0';
			IPString[1] = ((AppConfig.MyIPAddr.v[0] / 10) % 10) + '0';
			IPString[2] = ((AppConfig.MyIPAddr.v[0] / 1) % 10) + '0';
			IPString[4] = ((AppConfig.MyIPAddr.v[1] / 100) % 10) + '0';
			IPString[5] = ((AppConfig.MyIPAddr.v[1] / 10) % 10) + '0';
			IPString[6] = ((AppConfig.MyIPAddr.v[1] / 1) % 10) + '0';
			IPString[8] = ((AppConfig.MyIPAddr.v[2] / 100) % 10) + '0';
			IPString[9] = ((AppConfig.MyIPAddr.v[2] / 10) % 10) + '0';
			IPString[10] = ((AppConfig.MyIPAddr.v[2] / 1) % 10) + '0';
			IPString[12] = ((AppConfig.MyIPAddr.v[3] / 100) % 10) + '0';
			IPString[13] = ((AppConfig.MyIPAddr.v[3] / 10) % 10) + '0';
			IPString[14] = ((AppConfig.MyIPAddr.v[3] / 1) % 10) + '0';
			strcat(LCDPrintBuffer[1], IPString);
			strcatpgm2ram(LCDPrintBuffer[1], " MN ");
			strcat(LCDPrintBuffer[1], MNString);
//			strcatpgm2ram(LCDPrintBuffer[1], " SN ");
//			strcat(LCDPrintBuffer[1], SNString); // too long
			strcatpgm2ram(LCDPrintBuffer[1], " ");

			strcpypgm2ram(LCDPrintBuffer[0],  "[CVT.1] [CVT.2] [DC VOL]                ");
			//strcpypgm2ram(LCDBlinkBuffer[0], "[CVT.1] 	[CVT.2] 					");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;

/***************************CVT1 *******************************************/
		
		case MENU4:
		{
            strcpypgm2ram(LCDPrintBuffer[0], "DC1 [LO FREQ] [RF FREQ] [LO STATUS] [ATT");
		  //strcpypgm2ram(LCDPrintBuffer[0], "DC1 [LO FREQ] [RF FREQ] [LO STATUS] [ATT");
			strcpy(LCDPrintBuffer[1], LOFreqString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC1           [RF FREQ] [LO STATUS] [ATT");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU5:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC1 [RF FREQ] [LO STATUS] [ATTEN] [IF FR");
			strcpy(LCDPrintBuffer[1], RFFreqString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC1           [LO STATUS] [ATTEN] [IF FR");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU6:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC1 [LO STATUS] [ATTEN] [IF FREQ] [LO FR");
			if (ConverterAStatus == OK)
			{
				strcat(LCDPrintBuffer[1], LOStatusString1);
			}
			else
			{
				strcat(LCDPrintBuffer[1], LOStatusString2);
			}
			strcatpgm2ram(LCDPrintBuffer[1], "                           ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC1             [ATTEN] [IF FREQ] [LO FR");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU7:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC1 [ATTEN] [IF FREQ] [LO FREQ] [RF FREQ");
			strcpy(LCDPrintBuffer[1], AttenString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC1         [IF FREQ] [LO FREQ] [RF FREQ");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU8:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC1 [IF FREQ] [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDPrintBuffer[1], IFString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC1           [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;


		case MENU9:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC1 [IF FREQ] [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDPrintBuffer[1], IFString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC1           [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;


/*******************************CVT2**********************************/
		
		case MENU10:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [LO FREQ] [RF FREQ] [LO STATUS] [ATT");
			strcpy(LCDPrintBuffer[1], LOFreqString2);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2           [RF FREQ] [LO STATUS] [ATT");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU11:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [RF FREQ] [LO STATUS] [ATTEN] [IF FR");
			strcpy(LCDPrintBuffer[1], RFFreqString2);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2           [LO STATUS] [ATTEN] [IF FR");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU12:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [LO STATUS] [ATTEN] [IF FREQ] [LO FR");
			if (ConverterBStatus == OK)
			{
				strcat(LCDPrintBuffer[1], LOStatusString1);
			}
			else
			{
				strcat(LCDPrintBuffer[1], LOStatusString2);
			}
			strcatpgm2ram(LCDPrintBuffer[1], "                           ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2             [ATTEN] [IF FREQ] [LO FR");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU13:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [ATTEN] [IF FREQ] [LO FREQ] [RF FREQ");
			strcpy(LCDPrintBuffer[1], AttenString2);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2         [IF FREQ] [LO FREQ] [RF FREQ");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU14:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [IF FREQ] [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDPrintBuffer[1], IFString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2           [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;

		case MENU15:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [IF FREQ] [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDPrintBuffer[1], IFString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2           [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;


		/*******************VOL Ctrl *********************/

		case MENU16:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [IF FREQ] [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDPrintBuffer[1], IFString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2           [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;


		case MENU17:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "DC2 [IF FREQ] [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDPrintBuffer[1], IFString1);
			strcatpgm2ram(LCDPrintBuffer[1], "                             ");
			strcpypgm2ram(LCDBlinkBuffer[0], "DC2           [LO FREQ] [RF FREQ] [LO ST");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;

		


		/***********************Device Info****************************/
		case MENU18:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "INFO [IP] [MODULE NUMBER] [SERIAL NUMBER");
			strcpy(LCDPrintBuffer[1], IPString);
			strcatpgm2ram(LCDPrintBuffer[1], "                           ");
			strcpypgm2ram(LCDBlinkBuffer[0], "INFO      [MODULE NUMBER] [SERIAL NUMBER");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU19:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "INFO [IP] [MODULE NUMBER] [SERIAL NUMBER");
			strcpy(LCDPrintBuffer[1], MNString);
			strcatpgm2ram(LCDPrintBuffer[1], "        ");
			strcpypgm2ram(LCDBlinkBuffer[0], "INFO [IP]                 [SERIAL NUMBER");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		case MENU20:
		{
			strcpypgm2ram(LCDPrintBuffer[0], "INFO [IP] [MODULE NUMBER] [SERIAL NUMBER");
			strcpy(LCDPrintBuffer[1], SNString);
			strcatpgm2ram(LCDPrintBuffer[1], "               ");
			strcpypgm2ram(LCDBlinkBuffer[0], "INFO [IP] [MODULE NUMBER]               ");
			strcpy(LCDBlinkBuffer[1], LCDPrintBuffer[1]);
		}
		break;
		default :
		break;
	}
}





void KeyProcessing(void)
{
	unsigned char tempbuffer[16];
	DWORD tempDWORD = 0;
	WORD tempWORD = 0;

	switch (PressedKey)
	{
		case UPKEY:
		{
			if (EditMode == TRUE)
			{
				// update LCD display
				if ((LCDPrintBuffer[1][EditPosition] >= '0') && (LCDPrintBuffer[1][EditPosition] < '9'))
				{
					LCDPrintBuffer[1][EditPosition]++;
				}
				else if (LCDPrintBuffer[1][EditPosition] == '9')
				{
					LCDPrintBuffer[1][EditPosition] = '0';
				}
				LCDBlinkBuffer[1][EditPosition] = LCDPrintBuffer[1][EditPosition];
			}
			else
			{
				if (CurrentMenu <= MENU2) // Menu 0/1/2
				{
				}
				else if (CurrentMenu <= MENU7) // Menu 3/4/5/6/7
				{
					CurrentMenu = MENU0;
				}
				else if (CurrentMenu <= MENU12) // Menu 8/9/10/11/12
				{
					CurrentMenu = MENU1;
				}
				else if (CurrentMenu <= MENU15) // Menu 13/14/15
				{
					CurrentMenu = MENU2;
				}
				else
				{
				}
			}
		}
		break;
		case DOWNKEY:
		{
			if (EditMode == TRUE)
			{
				// update LCD display
				if ((LCDPrintBuffer[1][EditPosition] > '0') && (LCDPrintBuffer[1][EditPosition] <= '9'))
				{
					LCDPrintBuffer[1][EditPosition]--;
				}
				else if (LCDPrintBuffer[1][EditPosition] == '0')
				{
					LCDPrintBuffer[1][EditPosition] = '9';
				}
				LCDBlinkBuffer[1][EditPosition] = LCDPrintBuffer[1][EditPosition];
			}
			else
			{
				if (CurrentMenu == MENU0) // Menu 0
				{
					CurrentMenu = MENU3;
				}
				else if (CurrentMenu == MENU1) // Menu 1
				{
					CurrentMenu = MENU8;
				}
				else if (CurrentMenu == MENU2) // Menu 2
				{
					CurrentMenu = MENU13;
				}
				else
				{
				}
			}
		}
		break;
		case LEFTKEY:
		{
			if (EditMode == TRUE)
			{
				// update LCD display
				if ((CurrentMenu == MENU3) || (CurrentMenu == MENU8)) // Freq
				{
					if (EditPosition == 0)
					{
						EditPosition = 5;
					}
					else if (EditPosition == 5)
					{
						EditPosition = 3;
					}
					else
					{
						EditPosition--;
					}
				}
				else if ((CurrentMenu == MENU6) || (CurrentMenu == MENU11)) // Atten
				{
					if (EditPosition == 0)
					{
						EditPosition = 1;
					}
					else
					{
						EditPosition = 0;
					}
				}
				else if (CurrentMenu == MENU13) // IP
				{
					if (EditPosition == 0)
					{
						EditPosition = 14;
					}
					else if (EditPosition == 4)
					{
						EditPosition = 2;
					}
					else if (EditPosition == 8)
					{
						EditPosition = 6;
					}
					else if (EditPosition == 12)
					{
						EditPosition = 10;
					}
					else
					{
						EditPosition--;
					}
				}
				// void LCDDisplay(unsigned char displayflag, unsigned char cusorflag, unsigned char blinkflag)
				WriteIns(0xC0 + EditPosition);
				LCDDisplay(TRUE, TRUE, FALSE);
			}
			else
			{
				if (CurrentMenu == MENU0) // Menu 0
				{
					CurrentMenu = MENU2;
				}
				else if (CurrentMenu <= MENU2) // Menu 1/2
				{
					CurrentMenu--;
				}
				else if (CurrentMenu == MENU3) // Menu 3
				{
					CurrentMenu = MENU7;
				}
				else if (CurrentMenu <= MENU7) // Menu 4/5/6/7
				{
					CurrentMenu--;
				}
				else if (CurrentMenu == MENU8) // Menu 8
				{
					CurrentMenu = MENU12;
				}
				else if (CurrentMenu <= MENU12) // Menu 9/10/11/12
				{
					CurrentMenu--;
				}
				else if (CurrentMenu == MENU13) // Menu 13
				{
					CurrentMenu = MENU15;
				}
				else if (CurrentMenu <= MENU15) // Menu 14/15
				{
					CurrentMenu--;
				}
				else
				{
				}
			}
		}
		break;
		case RIGHTKEY:
		{
			if (EditMode == TRUE)
			{
				// update LCD display
				if ((CurrentMenu == MENU3) || (CurrentMenu == MENU8)) // Freq
				{
					if (EditPosition == 5)
					{
						EditPosition = 0;
					}
					else if (EditPosition == 3)
					{
						EditPosition = 5;
					}
					else
					{
						EditPosition++;
					}
				}
				else if ((CurrentMenu == MENU6) || (CurrentMenu == MENU11)) // Atten
				{
					if (EditPosition == 1)
					{
						EditPosition = 0;
					}
					else
					{
						EditPosition = 1;
					}
				}
				else if (CurrentMenu == MENU13) // IP
				{
					if (EditPosition == 14)
					{
						EditPosition = 0;
					}
					else if (EditPosition == 2)
					{
						EditPosition = 4;
					}
					else if (EditPosition == 6)
					{
						EditPosition = 8;
					}
					else if (EditPosition == 10)
					{
						EditPosition = 12;
					}
					else
					{
						EditPosition++;
					}
				}
				// void LCDDisplay(unsigned char displayflag, unsigned char cusorflag, unsigned char blinkflag)
				WriteIns(0xC0 + EditPosition);
				LCDDisplay(TRUE, TRUE, FALSE);
			}
			else
			{
				if (CurrentMenu <= MENU1) // Menu 0/1
				{
					CurrentMenu++;
				}
				else if (CurrentMenu == MENU2) // Menu 2
				{
					CurrentMenu = MENU0;
				}
				else if (CurrentMenu <= MENU6) // Menu 3/4/5/6
				{
					CurrentMenu++;
				}
				else if (CurrentMenu == MENU7) // Menu 7
				{
					CurrentMenu = MENU3;
				}
				else if (CurrentMenu <= MENU11) // Menu 8/9/10/11
				{
					CurrentMenu++;
				}
				else if (CurrentMenu == MENU12) // Menu 12
				{
					CurrentMenu = MENU8;
				}
				else if (CurrentMenu <= MENU14) // Menu 13/14
				{
					CurrentMenu++;
				}
				else if (CurrentMenu == MENU15) // Menu 15
				{
					CurrentMenu = MENU13;
				}
				else
				{
				}
			}
		}
		break;
		case ENTERKEY:
		{
			if (EditMode == TRUE)
			{
				// update LCD value to Freq/Atten/IP, TBD, update wrt power, ALC, Mute
				if (CurrentMenu == MENU3) // DC1 Freq
				{
					tempDWORD = LCDPrintBuffer[1][0] - '0';
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][1] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][2] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][3] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][5] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 100));
					if ((tempDWORD != stConverter.stUp.u32OutputFreq) && (tempDWORD <= MAXLOFREQ) && (tempDWORD >= MINLOFREQ))
					{
						stConverter.stUp.u32OutputFreq = tempDWORD;
						stI2CUCMsg.unRfFreq.u32Freq = tempDWORD;
						SetI2C(MODULE0);
					}
				}
				else if (CurrentMenu == MENU8) // DC2 Freq
				{
					tempDWORD = LCDPrintBuffer[1][0] - '0';
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][1] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][2] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][3] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 10)) + ((DWORD)LCDPrintBuffer[1][5] - '0');
					tempDWORD = ((DWORD)(tempDWORD * 100));
					if ((tempDWORD != stConverter.stDown.u32InputFreq) && (tempDWORD <= MAXLOFREQ) && (tempDWORD >= MINLOFREQ))
					{
						stConverter.stDown.u32InputFreq = tempDWORD;
						stI2CDCMsg.unRfFreq.u32Freq = tempDWORD;
						SetI2C(MODULE1);
					}
				}
				else if (CurrentMenu == MENU6) // DC1 Atten
				{
					tempWORD = LCDPrintBuffer[1][0] - '0';
					tempWORD = ((WORD)(tempWORD * 10)) + ((WORD)LCDPrintBuffer[1][1] - '0');
					tempWORD = ((WORD)(tempWORD * 10)) + ((DWORD)LCDPrintBuffer[1][3] - '0');
					if ((tempWORD != stConverter.stUp.u16Atten) && (tempWORD <= MAXATTEN))
					{
						stConverter.stUp.u16Atten = tempWORD;
						stI2CUCMsg.unAtten.u16Atten= tempDWORD;
						SetI2C(MODULE0);
					}
				}
				else if (CurrentMenu == MENU11) // DC2 Atten
				{
					tempWORD = LCDPrintBuffer[1][0] - '0';
					tempWORD = ((WORD)(tempWORD * 10)) + ((WORD)LCDPrintBuffer[1][1] - '0');
					tempWORD = ((WORD)(tempWORD * 10)) + ((DWORD)LCDPrintBuffer[1][3] - '0');
					if ((tempWORD != stConverter.stDown.u16Atten) && (tempWORD <= MAXATTEN))
					{
						stConverter.stDown.u16Atten = tempWORD;
						stI2CDCMsg.unAtten.u16Atten= tempDWORD;
						SetI2C(MODULE1);
					}
				}
				else if (CurrentMenu == MENU13) // IP
				{
					memcpy(tempbuffer, LCDPrintBuffer[1], 15);
					tempbuffer[15] = '\0';
	                if(StringToIPAddress(tempbuffer, &AppConfig.MyIPAddr))
	                {
	                	SaveSetting();
	                	SaveAppConfig();
	                }
				}


				LCDDisplay(TRUE, FALSE, FALSE);
				EditMode = FALSE;
				EditPosition = 0;
				break;
			}
			if (ConvertMenu[CurrentMenu].editable == TRUE)
			{
				EditMode = TRUE;
				EditPosition = 0;
			}
			RefreshFlag = TRUE;
		}
		break;
		case CANCELKEY:
		{
			EditMode = FALSE;
			EditPosition = 0;
			LCDDisplay(TRUE, FALSE, FALSE);
			RefreshFlag = TRUE;
		}
		break;
		default :
		break;
	}

}




// typedef union
// {
    // unsigned long u32Freq;
    // unsigned char u8Freq[4];
// }tunFreq;

// typedef union
// {
    // unsigned short int u16Atten;
    // unsigned char u8Atten[2];
// }tunAtten;

// typedef struct
// {
	// unsigned char u8Updateflag;   //BYTE 0
	// unsigned char LockStatus;   //BYTE 1
	// tunFreq       unRfFreq;     //BYTE 2-5 consider union here
    // tunAtten      unAtten;      //BYTE 6-7 consider union here
    // unsigned char u8WtPower;    //BYTE 8 Write outputpower to modules 
    // unsigned char u8RdPower;    //BYTE 9 Read outputpower from modules    

// }tstI2CMessage;


void UpdateStatus(void)
{
	DWORD tempDWORD = 0;
	WORD tempWORD = 0;
	BYTE u8TempByte = 0;


	/* Module Up Converter*/

	stI2CUCMsg.u8Updateflag = 0;
	I2C_Send(MODULE0_ADDRESS, (char*)&stI2CUCMsg, 1); //Notify Want to read I2C message
	I2C_Read(MODULE0_ADDRESS, (char*)&stI2CUCMsg, sizeof(tstI2CMessage)); //Read I2C message
	if (((stI2CUCMsg.u8CtrlStatus & I2C_nLOLOCK)== 0) && (stConverter.stUp.u8AlarmStatus != MAJORALARM))
	{
		RefreshFlag = TRUE;
		stConverter.stUp.u8AlarmStatus = MAJORALARM;
		stConverter.stUp.u8Lock = 0;
		strcpypgm2ram(LOStatusString1, "UNLOCKED");
	}
	else if (((stI2CUCMsg.u8CtrlStatus & I2C_nLOLOCK )!= 0) && (stConverter.stUp.u8AlarmStatus!= OK))
	{
		RefreshFlag = TRUE;
		stConverter.stUp.u8AlarmStatus = OK;
		stConverter.stUp.u8Lock = 1;
		strcpypgm2ram(LOStatusString1, "LOCKED");
	}


	u8TempByte = (stI2CUCMsg.u8CtrlStatus & I2C_nALC)>>1;
	if(u8TempByte != stConverter.stUp.u8ALC)
	{
		stConverter.stUp.u8ALC= u8TempByte;
		RefreshFlag = TRUE;

	}

	u8TempByte = (stI2CUCMsg.u8CtrlStatus & I2C_nMUTE)>>2;
	if(u8TempByte != stConverter.stUp.u8Mute)
	{
		stConverter.stUp.u8Mute= u8TempByte;
		RefreshFlag = TRUE;

	}	


    tempDWORD = stI2CUCMsg.unRfFreq.u32Freq;

	if (tempDWORD != stConverter.stUp.u32OutputFreq)
	{
		RefreshFlag = TRUE;
		stConverter.stUp.u32OutputFreq = tempDWORD;
	}

    
    tempWORD = stI2CUCMsg.unAtten.u16Atten;
	tempWORD /= 10;
	if (tempWORD != stConverter.stUp.u16Atten)
	{
		RefreshFlag = TRUE;
		stConverter.stUp.u16Atten = tempWORD;
	}


	u8TempByte = stI2CUCMsg.u8RdPower;
	if(u8TempByte != stConverter.stUp.u8OutputPower)
	{
		stConverter.stUp.u8OutputPower = u8TempByte;
		RefreshFlag = TRUE;

	}
    
    /* MSB displayed first at byte[0], Big Endians for display*/

	
	RFFreqString1[0] = ((stConverter.stUp.u32OutputFreq / 1000000) % 10) + '0';
	RFFreqString1[1] = ((stConverter.stUp.u32OutputFreq / 100000) % 10) + '0';
	RFFreqString1[2] = ((stConverter.stUp.u32OutputFreq / 10000) % 10) + '0';
	RFFreqString1[3] = ((stConverter.stUp.u32OutputFreq / 1000) % 10) + '0';
	/* 	'.'	 */
	RFFreqString1[5] = ((stConverter.stUp.u32OutputFreq / 100) % 10) + '0';
	RFFreqString1[6] = ((stConverter.stUp.u32OutputFreq / 10) % 10) + '0';
	RFFreqString1[7] = ((stConverter.stUp.u32OutputFreq % 10) % 10) + '0';	
	
	AttenString1[0] = ((stConverter.stUp.u16Atten / 100) % 10) + '0';
	AttenString1[1] = ((stConverter.stUp.u16Atten / 10) % 10) + '0';
	AttenString1[3] = ((stConverter.stUp.u16Atten / 1) % 10) + '0';

	

	/* Module Down Converter*/

	stI2CDCMsg.u8Updateflag = 0;
	I2C_Send(MODULE1_ADDRESS, (char*)&stI2CDCMsg, 1);
	I2C_Read(MODULE1_ADDRESS, (char*)&stI2CDCMsg, sizeof(tstI2CMessage));
	if (((stI2CDCMsg.u8CtrlStatus & I2C_nLOLOCK)== 0)  && (stConverter.stDown.u8AlarmStatus != MAJORALARM))
	{
		RefreshFlag = TRUE;
		stConverter.stDown.u8AlarmStatus = MAJORALARM;
		stConverter.stUp.u8Lock = 0;
		strcpypgm2ram(LOStatusString2, "UNLOCKED");
	}
	else if (((stI2CDCMsg.u8CtrlStatus & I2C_nLOLOCK)!= 0) && (stConverter.stDown.u8AlarmStatus != OK))
	{
		RefreshFlag = TRUE;
		stConverter.stDown.u8AlarmStatus = OK;
		stConverter.stUp.u8Lock = 1;
		strcpypgm2ram(LOStatusString2, "LOCKED");
	}


	u8TempByte = (stI2CDCMsg.u8CtrlStatus & I2C_nALC) >> 1;
	if(u8TempByte != stConverter.stDown.u8ALC)
	{
		stConverter.stDown.u8ALC= u8TempByte;
		RefreshFlag = TRUE;
	}
	u8TempByte = (stI2CDCMsg.u8CtrlStatus & I2C_nMUTE) >> 2;
	if(u8TempByte != stConverter.stDown.u8Mute)
	{
		stConverter.stDown.u8Mute= u8TempByte;
		RefreshFlag = TRUE;
	}	

    
    tempDWORD = stI2CDCMsg.unRfFreq.u32Freq;

    
	if (tempDWORD != stConverter.stDown.u32InputFreq)
	{
		RefreshFlag = TRUE;
		stConverter.stDown.u32InputFreq = tempDWORD;
	}

    
    
    tempWORD = stI2CDCMsg.unAtten.u16Atten;
	tempWORD /= 10;
	if (tempWORD != stConverter.stDown.u16Atten)
	{
		RefreshFlag = TRUE;
		stConverter.stDown.u16Atten = tempWORD;
	}

	u8TempByte = stI2CDCMsg.u8RdPower;
	if(u8TempByte != stConverter.stDown.u8OutputPower)
	{
		stConverter.stDown.u8OutputPower = u8TempByte;
		RefreshFlag = TRUE;

	}
	
	RFFreqString2[0] = ((stConverter.stDown.u32InputFreq / 1000000) % 10) + '0';
	RFFreqString2[1] = ((stConverter.stDown.u32InputFreq / 100000) % 10) + '0';
	RFFreqString2[2] = ((stConverter.stDown.u32InputFreq / 10000) % 10) + '0';
	RFFreqString2[3] = ((stConverter.stDown.u32InputFreq / 1000) % 10) + '0';
	/* 	'.'	 */
	RFFreqString2[5] = ((stConverter.stDown.u32InputFreq / 100) % 10) + '0';
	RFFreqString1[6] = ((stConverter.stDown.u32InputFreq / 10) % 10) + '0';
	RFFreqString1[7] = ((stConverter.stDown.u32InputFreq % 10) % 10) + '0';	
	
	AttenString2[0] = ((stConverter.stDown.u16Atten / 1000) % 10) + '0';
	AttenString2[1] = ((stConverter.stDown.u16Atten / 100) % 10) + '0';
	AttenString2[3] = ((stConverter.stDown.u16Atten / 10) % 10) + '0';
	
    
    /* Module Dc Control*/
	stI2CVOLMsg.u8Updateflag = 0;
	I2C_Send(MODULE2_ADDRESS, (char*)&stI2CVOLMsg, 1);
	I2C_Read(MODULE2_ADDRESS, (char*)&stI2CVOLMsg, sizeof(tstI2CMessageVOL));
    
    u8TempByte = stI2CVOLMsg.u818VDC;
    if(stConverter.stDC.u818VDC != u8TempByte )
    {
        stConverter.stDC.u818VDC = u8TempByte;
        RefreshFlag = TRUE;
    }

	if (1 != stConverter.stDC.u818VDC)
	{
		s18VDC[1] ='F';
		s18VDC[2] ='F';
	}
	else
	{
		s18VDC[1] ='N';
		s18VDC[2] =' ';

	}
    u8TempByte = stI2CVOLMsg.u824VDC;
    if(stConverter.stDC.u824VDC != u8TempByte )
    {
        stConverter.stDC.u824VDC = u8TempByte;
        RefreshFlag = TRUE;
    } 
    if (1 != stConverter.stDC.u824VDC)
	{
		s24VDC[1] ='F';
		s24VDC[2] ='F';
	}
	else
	{
		s24VDC[1] ='N';
		s24VDC[2] =' ';

	}
    
	// Update Webpage
	// Update SNMP
	// Update LCD
}


